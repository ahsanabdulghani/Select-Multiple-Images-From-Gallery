//
//  ViewController.swift
//  SelectMultpleIamgesFromGallery
//
//  Created by Pawan iOS on 14/12/2022.
//

import UIKit
import PhotosUI

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func openGalleyForimages(_ sender: UIButton) {
        var config = PHPickerConfiguration()
        config.selectionLimit = 3
        
        let phpicker = PHPickerViewController(configuration: config)
        phpicker.delegate = self
        self.present(phpicker, animated: true, completion: nil)
        
    }
}

extension ViewController: PHPickerViewControllerDelegate {
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        dismiss(animated: true)
        
        for result in results {
            result.itemProvider.loadObject(ofClass: UIImage.self) { object, error in
                if let image = object as? UIImage {
                    print(image)
                }
            }
        }
    }
}
    

